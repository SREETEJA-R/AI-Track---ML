import math as m
x_0=1
y_o=2
eta=0.9
eps=0.000001
del_x=1
del_y=1
max_iters=10000
iters=0
def deriv(x,y):
    x_deriv = 6*(x)
    y_deriv = (-5)*(m.exp(-y))
    return x_deriv,y_deriv

while max(abs(del_x),abs(del_y) )> eps and iters < max_iters:
    prev_x=x_0
    prev_y=y_o
    del_x,del_y= deriv(prev_x,prev_y)
    del_x=eta*del_x
    del_y=eta*del_y
    x_0= x_0 + del_x
    y_o = y_o + del_y
    iters=iters+1
    print("iterations",iters,"\n value is x: ",x_0,"y value is",y_o)
print("the local mim at\n",x_0,y_o)